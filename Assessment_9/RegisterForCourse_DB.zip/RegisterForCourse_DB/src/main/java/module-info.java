module edu.capella.bsit.registerforcourse {
    requires org.mariadb.jdbc;
    requires javafx.controls;
    exports edu.capella.bsit.registerforcourse;
}
