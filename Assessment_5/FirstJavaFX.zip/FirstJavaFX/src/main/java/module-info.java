module edu.capella.bsit.firstjavafx {
    requires javafx.controls;
    exports edu.capella.bsit.firstjavafx;
}
